#!/bin/bash
# Instalar Clarity Meter Pro.command
# Vai junto no pacote de download. Instala os plug-ins (VST3 e AAX; e o AU/app se vierem junto)
# nas pastas certas e tira o bloqueio do macOS de arquivos baixados da internet.

cd "$(dirname "$0")" || exit 1
NAME="Clarity Meter Pro"
APP="ClarityMeterPro.app"
VST3_DIR="$HOME/Library/Audio/Plug-Ins/VST3"
AU_DIR="$HOME/Library/Audio/Plug-Ins/Components"
AAX_DIR="/Library/Application Support/Avid/Audio/Plug-Ins"

echo ""
echo "=== Instalador do Clarity Meter Pro ==="
echo "Desenvolvido por Palitomix (@PalitoMix_)"
echo ""
echo "Vou instalar:"
[ -d "$APP" ] && echo "  • App Clarity Meter Pro            -> Aplicativos"
[ -d "$NAME.vst3" ] && echo "  • Plug-in VST3                     -> $VST3_DIR"
[ -d "$NAME.component" ] && echo "  • Plug-in AU (Logic)               -> $AU_DIR"
[ -d "$NAME.aaxplugin" ] && echo "  • Plug-in AAX (Pro Tools)          -> $AAX_DIR"
echo ""
echo "O Mac vai pedir a sua senha (ao digitar ela não aparece, é normal)."
read -r -p "Pressione Enter para começar, ou feche esta janela para cancelar... "

# libera tudo o que veio no download (tira a "quarentena" do macOS)
xattr -dr com.apple.quarantine . 2>/dev/null

ok=0; erro=0
instalar() { # $1 = origem, $2 = pasta destino, $3 = usar sudo (1/0)
  local src="$1" dst="$2" su="$3"
  [ -d "$src" ] || return 0
  if [ "$su" = "1" ]; then
    sudo mkdir -p "$dst" && sudo rm -rf "$dst/$src" && sudo cp -R "$src" "$dst/" \
      && sudo xattr -dr com.apple.quarantine "$dst/$src" 2>/dev/null
  else
    mkdir -p "$dst" && rm -rf "$dst/$src" && cp -R "$src" "$dst/" \
      && xattr -dr com.apple.quarantine "$dst/$src" 2>/dev/null
  fi
  if [ -d "$dst/$src" ]; then echo "  ✔ $src"; ok=$((ok+1)); else echo "  ✘ $src (não consegui copiar)"; erro=$((erro+1)); fi
}

echo ""
instalar "$APP" "/Applications" 1
instalar "$NAME.vst3" "$VST3_DIR" 0
instalar "$NAME.component" "$AU_DIR" 0
instalar "$NAME.aaxplugin" "$AAX_DIR" 1

# faz o macOS reler a lista de Audio Units (Logic)
killall -9 AudioComponentRegistrar >/dev/null 2>&1

echo ""
if [ "$erro" = "0" ]; then
  echo "PRONTO! $ok item(ns) instalado(s)."
  echo ""
  if [ -d "$APP" ]; then
    echo "• App: abra \"Clarity Meter Pro\" em Aplicativos. Na 1ª vez ele oferece instalar o dispositivo de áudio."
    echo "  Depois, em Opções: entrada = Clarity Meter Pro, saída = sua interface."
  fi
  echo "• Na DAW: procure \"Clarity Meter Pro\" (fabricante Palitomix)."
  echo "  Pro Tools: categoria Sound Field (insira como multichannel > stereo). Logic: Audio Units > Palitomix."
  echo "  Se a DAW já estava aberta, feche e abra de novo."
else
  echo "Terminou com $erro erro(s). Tente rodar de novo ou copie os arquivos à mão (veja o LEIA-ME)."
fi
echo ""
read -r -p "Pressione Enter para fechar..."
